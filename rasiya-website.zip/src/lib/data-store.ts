// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//   مخزن البيانات — يقرأ ويكتب من localStorage
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export interface BlogPost {
  title: string;
  excerpt: string;
  date: string;
  link: string;
  image?: string;
}

export interface Product {
  name: string;
  description: string;
  price: number;
  image?: string;
}

const BLOG_KEY = 'rasiya_blog_posts';
const PRODUCTS_KEY = 'rasiya_products';

/** قراءة المقالات من localStorage أو الرجوع للقيم الافتراضية */
export function getBlogPosts(defaults: BlogPost[]): BlogPost[] {
  if (typeof window === 'undefined') return defaults;
  try {
    const stored = localStorage.getItem(BLOG_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}
  return defaults;
}

/** حفظ المقالات في localStorage */
export function saveBlogPosts(posts: BlogPost[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(BLOG_KEY, JSON.stringify(posts));
}

/** قراءة المنتجات من localStorage أو الرجوع للقيم الافتراضية */
export function getProducts(defaults: Product[]): Product[] {
  if (typeof window === 'undefined') return defaults;
  try {
    const stored = localStorage.getItem(PRODUCTS_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}
  return defaults;
}

/** حفظ المنتجات في localStorage */
export function saveProducts(products: Product[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
}