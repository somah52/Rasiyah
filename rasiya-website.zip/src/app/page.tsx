'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Anchor,
  CheckCircle2,
  Clock,
  CreditCard,
  Sparkles,
  Shield,
  Heart,
  Compass,
  Star,
  ArrowLeft,
  CalendarCheck,
  MessageCircle,
  X,
  Send,
  Bot,
  User,
  Loader2,
  Crown,
  Quote,
  BookOpen,
  ShoppingBag,
  Instagram,
} from 'lucide-react';
import { useState, useRef, useEffect, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  siteConfig,
  getPackageBookingLink,
  getDiagnosticBookingLink,
  getProductLink,
  getWhatsAppLink,
} from '@/lib/site-config';
import { getBlogPosts, getProducts } from '@/lib/data-store';

/* ────────────────────── Animations ────────────────────── */
const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-40px' },
  transition: { duration: 0.6, ease: 'easeOut' },
};
const stagger = {
  initial: {},
  whileInView: { transition: { staggerChildren: 0.12 } },
  viewport: { once: true },
};
const packageIcons = [Compass, Anchor, Crown];
const procedureIcons = [Clock, CreditCard, Shield];

/* ────────────────────── ChatBot ────────────────────── */
interface ChatMessage { id: string; role: 'user' | 'assistant'; content: string; }

function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: 'w', role: 'assistant', content: 'مرحباً بكِ في راسية. أنا المساعد الذكي، هنا لمساعدتكِ في معرفة المزيد عن مسار الكوتشينج والباقات المتاحة. كيف يمكنني مساعدتكِ؟' },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  useEffect(() => { if (isOpen) setTimeout(() => inputRef.current?.focus(), 300); }, [isOpen]);

  const send = async () => {
    if (!input.trim() || isLoading) return;
    const m: ChatMessage = { id: Date.now().toString(), role: 'user', content: input.trim() };
    setMessages((p) => [...p, m]); setInput(''); setIsLoading(true);
    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: m.content, history: messages.map((x) => ({ role: x.role, content: x.content })) }) });
      const d = await res.json();
      setMessages((p) => [...p, { id: (Date.now() + 1).toString(), role: 'assistant', content: d.message || 'عذراً، حدث خطأ.' }]);
    } catch { setMessages((p) => [...p, { id: (Date.now() + 1).toString(), role: 'assistant', content: 'عذراً، لم أتمكن من الرد حالياً.' }]); }
    finally { setIsLoading(false); }
  };

  return (
    <>
      <motion.div className="fixed bottom-6 left-6 z-50" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 1.5 }}>
        <Button onClick={() => setIsOpen(!isOpen)} size="lg" className="rounded-full w-16 h-16 shadow-2xl cursor-pointer bg-sky-600 hover:bg-sky-700 text-white">
          {isOpen ? <X className="w-7 h-7" /> : <MessageCircle className="w-7 h-7" />}
        </Button>
        {!isOpen && <motion.span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-xs rounded-full flex items-center justify-center font-bold" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 2 }}>1</motion.span>}
      </motion.div>
      {isOpen && (
        <motion.div className="fixed bottom-28 left-6 z-50 w-[calc(100vw-3rem)] sm:w-[380px]" initial={{ opacity: 0, y: 20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }}>
          <Card className="shadow-2xl border-0 overflow-hidden">
            <div className="bg-gradient-to-l from-sky-600 to-blue-700 text-white p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm"><Bot className="w-6 h-6" /></div>
                <div><h3 className="font-bold text-lg">مساعد راسية</h3><div className="flex items-center gap-1.5"><span className="w-2 h-2 bg-green-300 rounded-full animate-pulse" /><span className="text-sm text-sky-100">متصل الآن</span></div></div>
              </div>
            </div>
            <ScrollArea className="h-80 p-4">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={`flex gap-2.5 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-sky-100 text-sky-700' : 'bg-gray-100 text-gray-500'}`}>
                      {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>
                    <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${msg.role === 'user' ? 'bg-sky-600 text-white rounded-br-sm' : 'bg-gray-100 text-gray-800 rounded-bl-sm'}`}>{msg.content}</div>
                  </div>
                ))}
                {isLoading && <div className="flex gap-2.5"><div className="w-8 h-8 rounded-full bg-gray-100 text-gray-500 flex items-center justify-center flex-shrink-0"><Bot className="w-4 h-4" /></div><div className="bg-gray-100 rounded-2xl rounded-bl-sm px-4 py-3"><Loader2 className="w-4 h-4 animate-spin text-gray-400" /></div></div>}
                <div ref={endRef} />
              </div>
            </ScrollArea>
            <div className="p-3 border-t bg-gray-50/80">
              <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2">
                <Input ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), send())} placeholder="اكتب رسالتك..." disabled={isLoading} className="rounded-full bg-white border-gray-200 focus:border-sky-500 text-right" />
                <Button type="submit" size="icon" disabled={!input.trim() || isLoading} className="rounded-full bg-sky-600 hover:bg-sky-700 text-white flex-shrink-0 cursor-pointer"><Send className="w-4 h-4" /></Button>
              </form>
            </div>
          </Card>
        </motion.div>
      )}
    </>
  );
}

/* ────────────────────── Data ────────────────────── */
const { coach, diagnosticSession, packages, procedures, social, testimonials } = siteConfig;

function useDynamicData() {
  const [blogPosts, setBlogPosts] = useState(siteConfig.blogPosts);
  const [products, setProducts] = useState(siteConfig.products);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setBlogPosts(getBlogPosts(siteConfig.blogPosts));
    setProducts(getProducts(siteConfig.products));
    setLoaded(true);
  }, []);

  // الاستماع للتغييرات من لوحة التحكم
  useEffect(() => {
    const handler = () => {
      setBlogPosts(getBlogPosts(siteConfig.blogPosts));
      setProducts(getProducts(siteConfig.products));
    };
    window.addEventListener('rasiya-data-updated', handler);
    return () => window.removeEventListener('rasiya-data-updated', handler);
  }, []);

  return { blogPosts, products, loaded };
}

const whatIsRasiya = [
  { icon: Heart, title: 'وعي ذاتي عميق', description: 'نموذج راسية يبدأ من داخلِك — يساعدك على فهم أنماطك العاطفية والفكرية وكيف تؤثر على علاقاتك وقراراتك.' },
  { icon: Compass, title: 'مواءمة حقيقية', description: 'نبدأ دائماً بجلسة تشخيص ومواءمة لنتأكد أن المسار يتناسب مع احتياجكِ الفعلي وأهدافكِ الحقيقية.' },
  { icon: Anchor, title: 'مرافقة التحول', description: 'ليست مجرد جلسات — هي رحلة مرافقة متكاملة نعبر فيها معاً من حالة إلى أخرى بوعي وثبات واستقلالية.' },
];

// قسم المدونة والمنتجات يظهر دائماً

/* ────────────────────── Page ────────────────────── */
export default function Home() {
  const { blogPosts, products, loaded } = useDynamicData();
  return (
    <div className="min-h-screen flex flex-col">
      {/* ─── Navigation ─── */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-sky-100/60">
        <nav className="container mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-blue-600 rounded-xl flex items-center justify-center text-white"><Anchor className="w-5 h-5" /></div>
            <span className="text-2xl font-bold bg-gradient-to-l from-sky-600 to-blue-700 bg-clip-text text-transparent">راسية</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-500">
            <a href="#about" className="hover:text-sky-600 transition-colors">عن راسية</a>
            <a href="#packages" className="hover:text-sky-600 transition-colors">الباقات</a>
            <a href="#coach" className="hover:text-sky-600 transition-colors">الكوتش</a>
            <a href="#blog" className="hover:text-sky-600 transition-colors">المدونة</a>
            <a href="#products" className="hover:text-sky-600 transition-colors">المنتجات</a>
          </div>
          <Button asChild className="bg-sky-600 hover:bg-sky-700 text-white cursor-pointer">
            <a href={getDiagnosticBookingLink()} target="_blank" rel="noopener noreferrer">احجز جلستك</a>
          </Button>
        </nav>
      </header>

      <main className="flex-1">
        {/* ─── Hero ─── */}
        <section className="relative overflow-hidden bg-gradient-to-bl from-sky-50 via-white to-blue-50">
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #0ea5e9 1px, transparent 0)', backgroundSize: '40px 40px' }} />
          <div className="container mx-auto px-4 sm:px-6 py-20 md:py-32 relative">
            <div className="max-w-3xl mx-auto text-center space-y-8">
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
                <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 px-4 py-1.5 text-sm font-medium">نموذج كوتشينج وعي وعلاقات</Badge>
              </motion.div>
              <motion.h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}>
                راسية
                <br />
                <span className="bg-gradient-to-l from-sky-600 to-blue-600 bg-clip-text text-transparent text-3xl md:text-5xl">مرافقة الوعي نحو الاستقلالية</span>
              </motion.h1>
              <motion.p className="text-lg md:text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}>
                يسعدني مرافقتكِ في مسار راسية — نموذج كوتشينج فريد يجمع بين الوعي الذاتي العميق والمرافقة الحقيقية نحو التحوّل في حياتكِ وعلاقاتكِ.
              </motion.p>
              <motion.div className="flex flex-col sm:flex-row items-center justify-center gap-4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}>
                <Button size="lg" asChild className="bg-sky-600 hover:bg-sky-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-sky-600/20 cursor-pointer">
                  <a href="#packages">اكتشفي الباقات <ArrowLeft className="w-5 h-5 mr-2" /></a>
                </Button>
                <Button size="lg" variant="outline" asChild className="border-sky-600 text-sky-600 hover:bg-sky-50 px-8 py-6 text-lg rounded-xl cursor-pointer">
                  <a href="#about">تعرّفي على راسية</a>
                </Button>
              </motion.div>
              <motion.p className="text-sm text-gray-400" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.5 }}>
                تبدأ الرحلة بجلسة تشخيص ومواءمة — {diagnosticSession.price} ريال فقط
              </motion.p>
            </div>
          </div>
        </section>

        {/* ─── What is Rasiya ─── */}
        <section id="about" className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="text-center mb-16" {...fadeUp}>
              <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">عن راسية</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">ما هو نموذج راسية؟</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-lg">نموذج كوتشينج متكامل صُمّم لمرافقتكِ في رحلة الوعي والعلاقات — من التشخيص العميق إلى الاستقلالية الحقيقية.</p>
            </motion.div>
            <motion.div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto" {...stagger}>
              {whatIsRasiya.map((item, i) => (
                <motion.div key={i} {...fadeUp}>
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-sky-100 rounded-2xl flex items-center justify-center mx-auto"><item.icon className="w-8 h-8 text-sky-600" /></div>
                    <h3 className="text-xl font-bold text-gray-900">{item.title}</h3>
                    <p className="text-gray-500 leading-relaxed">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ─── Coach Section ─── */}
        <section id="coach" className="py-20 md:py-28 bg-gray-50/60">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="max-w-5xl mx-auto" {...fadeUp}>
              <div className="text-center mb-12">
                <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">الكوتش</Badge>

              </div>
              <Card className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-8 md:p-12">
                  <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                    <div className="w-32 h-32 md:w-40 md:h-40 rounded-2xl bg-gradient-to-br from-sky-100 to-blue-100 flex items-center justify-center flex-shrink-0">
                      <span className="text-5xl md:text-6xl font-bold text-sky-300">س</span>
                    </div>
                    <div className="flex-1 text-center md:text-right space-y-5">
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900">{coach.name}</h3>
                        <p className="text-sky-600 font-medium text-lg">{coach.title}</p>
                      </div>
                      <p className="text-gray-500 leading-relaxed">{coach.bio}</p>

                      {/* Certificates */}
                      <div className="space-y-3">
                        <h4 className="font-bold text-gray-800">الشهادات والاعتمادات:</h4>
                        <div className="space-y-2">
                          {coach.certificates.map((cert, ci) => (
                            <div key={ci} className="flex items-start gap-2 text-sm">
                              <CheckCircle2 className="w-4 h-4 text-sky-500 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-700">{cert}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="flex items-center gap-6 justify-center md:justify-start pt-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="text-sm font-medium text-gray-700">{coach.clientsCount} عميلة راضية</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="w-4 h-4 text-rose-400" />
                          <span className="text-sm font-medium text-gray-700">{coach.sessionsCount} جلسة مكتملة</span>
                        </div>
                      </div>

                      {/* Social Links */}
                      <div className="flex items-center gap-3 justify-center md:justify-start pt-2">
                        {social.instagram && (
                          <Button asChild variant="outline" size="sm" className="rounded-xl border-pink-200 text-pink-600 hover:bg-pink-50 cursor-pointer">
                            <a href={social.instagram} target="_blank" rel="noopener noreferrer">
                              <Instagram className="w-4 h-4 ml-1.5" />
                              انستغرام
                            </a>
                          </Button>
                        )}
                        {social.tiktok && (
                          <Button asChild variant="outline" size="sm" className="rounded-xl border-gray-200 text-gray-700 hover:bg-gray-50 cursor-pointer">
                            <a href={social.tiktok} target="_blank" rel="noopener noreferrer">
                              <svg className="w-4 h-4 ml-1.5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 00-.79-.05A6.34 6.34 0 003.15 15.2a6.34 6.34 0 0010.86 4.48V13a8.27 8.27 0 005.58 2.17v-3.44a4.85 4.85 0 01-3.59-1.52z" /></svg>
                              تيك توك
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* ─── Testimonials ─── */}
        {testimonials.length > 0 && (
          <section className="py-20 md:py-28">
            <div className="container mx-auto px-4 sm:px-6">
              <motion.div className="text-center mb-16" {...fadeUp}>
                <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">آراء العملاء</Badge>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">ماذا تقول عميلاتنا</h2>
                <p className="text-gray-500 max-w-2xl mx-auto text-lg">تجارب حقيقية من عميلات مررن بمسار راسية</p>
              </motion.div>
              <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto" {...stagger}>
                {testimonials.map((t, i) => (
                  <motion.div key={i} {...fadeUp}>
                    <Card className="h-full border-0 shadow-sm hover:shadow-lg transition-shadow duration-300">
                      <CardContent className="p-6 md:p-8 space-y-4">
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((s) => <Star key={s} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                        </div>
                        <div className="relative">
                          <Quote className="w-8 h-8 text-sky-200 absolute -top-1 -right-1" />
                          <p className="text-gray-700 leading-relaxed pr-6">{t.text}</p>
                        </div>
                        <Separator />
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-sky-100 to-blue-100 flex items-center justify-center">
                            <span className="text-sm font-bold text-sky-500">{t.name.charAt(0)}</span>
                          </div>
                          <span className="text-sm font-medium text-gray-600">{t.name}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </section>
        )}

        {/* ─── Diagnostic Session ─── */}
        <section className="py-16 bg-gradient-to-l from-sky-600 to-blue-700">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="max-w-3xl mx-auto text-center text-white space-y-6" {...fadeUp}>
              <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-5 py-2 text-sm"><Sparkles className="w-4 h-4" />الخطوة الأولى</div>
              <h2 className="text-3xl md:text-4xl font-bold">جلسة التشخيص والمواءمة</h2>
              <p className="text-sky-100 text-lg leading-relaxed max-w-xl mx-auto">
                لضمان مواءمة مسار راسية مع احتياجكِ الفعلي، نبدأ بجلسة تشخيص ومواءمة مدتها {diagnosticSession.duration}. فيها نتعرف على وضعكِ الحالي، نحدد أهدافكِ، ونختار معاً الباقة الأنسب لرحلتكِ.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-2">
                <div><span className="text-4xl font-bold">{diagnosticSession.price}</span><span className="text-sky-200 mr-1">ريال فقط</span></div>
                <Separator orientation="vertical" className="hidden sm:block h-12 bg-white/20" />
                <div className="flex items-center gap-2 text-sky-100"><Clock className="w-5 h-5" /><span>{diagnosticSession.duration}</span></div>
                <Separator orientation="vertical" className="hidden sm:block h-12 bg-white/20" />
                <div className="flex items-center gap-2 text-sky-100"><CalendarCheck className="w-5 h-5" /><span>أونلاين</span></div>
              </div>
              <Button size="lg" asChild className="bg-white text-sky-700 hover:bg-sky-50 px-8 py-6 text-lg rounded-xl shadow-lg mt-4 cursor-pointer">
                <a href={getDiagnosticBookingLink()} target="_blank" rel="noopener noreferrer">احجزي جلسة التشخيص</a>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* ─── Packages ─── */}
        <section id="packages" className="py-20 md:py-28 bg-gray-50/60">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="text-center mb-16" {...fadeUp}>
              <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">الباقات</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">خيارات المرافقة الاستشارية</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-lg">اختري الباقة التي تناسب احتياجاتكِ ومرحلتكِ الحالية. كل باقة مصممة لتقديم أعمق تجربة تحول.</p>
            </motion.div>
            <motion.div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto" {...stagger}>
              {packages.map((pkg, i) => {
                const PkgIcon = packageIcons[i] || Compass;
                return (
                  <motion.div key={i} {...fadeUp}>
                    <Card className={`relative h-full border-0 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden ${pkg.highlighted ? 'ring-2 ring-sky-500 shadow-sky-500/10' : ''}`}>
                      {pkg.highlighted && <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-l from-sky-500 to-blue-600" />}
                      <CardContent className="p-6 md:p-8 flex flex-col h-full">
                        <div className="space-y-4 flex-1">
                          <div className="flex items-center justify-between">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${pkg.highlighted ? 'bg-sky-100 text-sky-600' : 'bg-gray-100 text-gray-500'}`}><PkgIcon className="w-6 h-6" /></div>
                            {pkg.highlighted && <Badge className="bg-sky-600 text-white hover:bg-sky-600">الأكثر طلباً</Badge>}
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">حزمة {pkg.name}</h3>
                            <p className="text-gray-500 text-sm mt-1 leading-relaxed">{pkg.description}</p>
                          </div>
                          <div className="flex items-baseline gap-1 pt-2">
                            <span className="text-3xl font-bold text-gray-900">{pkg.price.toLocaleString('ar-SA')}</span>
                            <span className="text-gray-400 text-sm">ريال</span>
                          </div>
                          <Separator />
                          <ul className="space-y-3">
                            {pkg.features.map((f, fi) => (
                              <li key={fi} className="flex items-start gap-2.5 text-sm">
                                <CheckCircle2 className={`w-4 h-4 mt-0.5 flex-shrink-0 ${pkg.highlighted ? 'text-sky-500' : 'text-gray-400'}`} />
                                <span className="text-gray-700">{f}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <Button asChild className={`w-full mt-6 py-5 text-base rounded-xl cursor-pointer ${pkg.highlighted ? 'bg-sky-600 hover:bg-sky-700 text-white shadow-lg shadow-sky-600/20' : 'bg-gray-100 hover:bg-gray-200 text-gray-800'}`}>
                          <a href={getPackageBookingLink(pkg.name, pkg.price)} target="_blank" rel="noopener noreferrer">احجزي عبر واتساب</a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        {/* ─── Procedures ─── */}
        <section id="procedures" className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="text-center mb-16" {...fadeUp}>
              <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">ملاحظات إجرائية</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">لضمان جودة رحلتكِ</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-lg">إجراءات بسيطة نلتزم بها معاً لضمان أقصى استفادة من كل جلسة ومن المسار ككل.</p>
            </motion.div>
            <motion.div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto" {...stagger}>
              {procedures.map((item, i) => {
                const ProcIcon = procedureIcons[i] || Shield;
                return (
                  <motion.div key={i} {...fadeUp}>
                    <Card className="h-full border-0 shadow-sm hover:shadow-lg transition-shadow duration-300">
                      <CardContent className="p-6 space-y-4 text-center">
                        <div className="w-14 h-14 bg-sky-50 rounded-2xl flex items-center justify-center mx-auto"><ProcIcon className="w-7 h-7 text-sky-600" /></div>
                        <h3 className="text-lg font-bold text-gray-900">{item.title}</h3>
                        <p className="text-gray-500 text-sm leading-relaxed">{item.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        {/* ─── Blog ─── */}
        <section id="blog" className="py-20 md:py-28 bg-gray-50/60">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="text-center mb-16" {...fadeUp}>
              <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100 mb-4">المدونة</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">مواضيع في الوعي والعلاقات</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-lg">مقالات تساعدكِ على التعمق في فهم ذاتكِ وعلاقاتكِ.</p>
            </motion.div>
            {blogPosts.length > 0 ? (
              <motion.div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto" {...stagger}>
                {blogPosts.map((post, i) => (
                  <motion.div key={`blog-${i}`} {...fadeUp}>
                    <Card className="h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 overflow-hidden group">
                      {post.image ? (
                        <div className="aspect-[16/9] overflow-hidden"><img src={post.image} alt={post.title} className="w-full h-full object-cover" /></div>
                      ) : (
                        <div className="aspect-[16/9] bg-gradient-to-br from-sky-100 to-blue-100 flex items-center justify-center">
                          <BookOpen className="w-12 h-12 text-sky-300 group-hover:text-sky-500 transition-colors" />
                        </div>
                      )}
                      <CardContent className="p-5 space-y-3">
                        {post.date && <p className="text-xs text-gray-400">{post.date}</p>}
                        <h3 className="font-bold text-gray-900 group-hover:text-sky-600 transition-colors">{post.title}</h3>
                        <p className="text-gray-500 text-sm leading-relaxed line-clamp-3">{post.excerpt}</p>
                        <Button asChild variant="ghost" size="sm" className="text-sky-600 hover:text-sky-700 cursor-pointer p-0 h-auto">
                          <a href={post.link || '#'} target="_blank" rel="noopener noreferrer">
                            اقرئي المزيد <ArrowLeft className="w-4 h-4 mr-1" />
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <p className="text-center text-gray-400 text-lg">قريباً — مقالات جديدة في الطريق</p>
            )}
          </div>
        </section>

        {/* ─── Products ─── */}
        <section id="products" className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="text-center mb-16" {...fadeUp}>
              <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 mb-4">المنتجات</Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">كتيبات وأدلة عملية</h2>
              <p className="text-gray-500 max-w-2xl mx-auto text-lg">أدوات عملية تساعدكِ في رحلة الوعي — حمّليها وابدأي فوراً.</p>
            </motion.div>
            {products.length > 0 ? (
              <motion.div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto" {...stagger}>
                {products.map((prod, i) => (
                  <motion.div key={`prod-${i}`} {...fadeUp}>
                    <Card className="h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 overflow-hidden group">
                      {prod.image ? (
                        <div className="aspect-[16/9] overflow-hidden"><img src={prod.image} alt={prod.name} className="w-full h-full object-cover" /></div>
                      ) : (
                        <div className="aspect-[16/9] bg-gradient-to-br from-emerald-50 to-teal-100 flex items-center justify-center">
                          <ShoppingBag className="w-12 h-12 text-emerald-300 group-hover:text-emerald-500 transition-colors" />
                        </div>
                      )}
                      <CardContent className="p-5 space-y-3">
                        <div className="flex items-center gap-2">
                          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-xs">كتيب</Badge>
                          <span className="text-lg font-bold text-gray-900">{prod.price} ريال</span>
                        </div>
                        <h3 className="font-bold text-gray-900 group-hover:text-sky-600 transition-colors">{prod.name}</h3>
                        <p className="text-gray-500 text-sm leading-relaxed line-clamp-2">{prod.description}</p>
                        <Button asChild size="sm" className="bg-sky-600 hover:bg-sky-700 text-white cursor-pointer w-full rounded-xl">
                          <a href={getProductLink(prod.name, prod.price)} target="_blank" rel="noopener noreferrer">اطلبي عبر واتساب</a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <p className="text-center text-gray-400 text-lg">قريباً — كتيبات جديدة في الطريق</p>
            )}
          </div>
        </section>

        {/* ─── CTA ─── */}
        <section className="py-20 md:py-28">
          <div className="container mx-auto px-4 sm:px-6">
            <motion.div className="bg-gradient-to-l from-sky-600 to-blue-700 rounded-3xl p-10 md:p-16 text-center text-white relative overflow-hidden" {...fadeUp}>
              <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '30px 30px' }} />
              <div className="relative z-10 space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold">جاهزة لبدء رحلتكِ؟</h2>
                <p className="text-sky-100 text-lg max-w-xl mx-auto leading-relaxed">احجزي جلسة التشخيص والمواءمة الآن وابدأي مسار راسية بـ {diagnosticSession.price} ريال فقط. خطوة واحدة نحو التغيير الحقيقي.</p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button size="lg" asChild className="bg-white text-sky-700 hover:bg-sky-50 px-8 py-6 text-lg rounded-xl shadow-lg cursor-pointer">
                    <a href={getDiagnosticBookingLink()} target="_blank" rel="noopener noreferrer">احجزي الآن — {diagnosticSession.price} ريال</a>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-xl cursor-pointer">
                    <a href="#packages">قارني الباقات</a>
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* ─── Footer ─── */}
      <footer className="bg-gray-900 text-gray-400 mt-auto">
        <div className="container mx-auto px-4 sm:px-6 py-12">
          <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-8">
            <div className="text-center md:text-right">
              <div className="flex items-center gap-2.5 justify-center md:justify-start mb-3">
                <div className="w-9 h-9 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center text-white"><Anchor className="w-4 h-4" /></div>
                <span className="text-xl font-bold text-white">راسية</span>
              </div>
              <p className="text-sm leading-relaxed max-w-xs">نموذج كوتشينج وعي وعلاقات — مرافقة حقيقية نحو التحول والاستقلالية.</p>
              {/* Social in Footer */}
              <div className="flex items-center gap-3 justify-center md:justify-start mt-4">
                {social.instagram && (
                  <a href={social.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-pink-400 transition-colors"><Instagram className="w-5 h-5" /></a>
                )}
                {social.tiktok && (
                  <a href={social.tiktok} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 00-.79-.05A6.34 6.34 0 003.15 15.2a6.34 6.34 0 0010.86 4.48V13a8.27 8.27 0 005.58 2.17v-3.44a4.85 4.85 0 01-3.59-1.52z" /></svg>
                  </a>
                )}
                <a href={getWhatsAppLink('مرحباً من موقع راسية')} target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
                </a>
              </div>
            </div>
            <div className="flex flex-col items-center md:items-end gap-3">
              <div className="flex items-center gap-6">
                <a href="#about" className="hover:text-sky-400 transition-colors text-sm">عن راسية</a>
                <a href="#packages" className="hover:text-sky-400 transition-colors text-sm">الباقات</a>
                <a href="#coach" className="hover:text-sky-400 transition-colors text-sm">الكوتش</a>
                <a href="#blog" className="hover:text-sky-400 transition-colors text-sm">المدونة</a>
                <a href="#products" className="hover:text-sky-400 transition-colors text-sm">المنتجات</a>
              </div>
              <Button asChild variant="ghost" size="sm" className="text-gray-500 hover:text-sky-400 cursor-pointer">
                <a href={getDiagnosticBookingLink()} target="_blank" rel="noopener noreferrer">احجز جلستك</a>
              </Button>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm">
            <p>&copy; {new Date().getFullYear()} راسية — جميع الحقوق محفوظة</p>
            <p>{coach.name} — {coach.title}</p>
          </div>
        </div>
      </footer>

      <ChatBot />
    </div>
  );
}