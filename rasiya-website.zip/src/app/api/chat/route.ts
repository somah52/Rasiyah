import { NextRequest, NextResponse } from 'next/server';

const SYSTEM_PROMPT = `أنت المساعد الذكي لمنصة "راسية" — نموذج كوتشينج متخصص في الوعي والعلاقات. الكوتش تقدم جلسات كوتشينج وباقات متنوعة.

المعلومات الأساسية عن راسية:
- نموذج راسية هو نموذج كوتشينج فريد يجمع بين الوعي الذاتي العميق والمرافقة العملية نحو التحوّل في حياة المتدربات وعلاقاتهن.
- تخصص الكوتش: الوعي والعلاقات.

جلسة التشخيص والمواءمة:
- المدة: 20-30 دقيقة
- السعر: 70 ريال
- الغرض: لضمان مواءمة المسار مع احتياج العميل الفعلية قبل البدء.

الباقات المتاحة:

1. حزمة الأساس — 150 ريال:
   - جلسة فردية واحدة (60 دقيقة)
   - تحديد الهدف الرئيسي للجلسة
   - خطة عمل مختصرة بعد الجلسة
   - متابعة نصية خلال الأسبوع

2. حزمة العبور — 500 ريال:
   - مسار راسية المتكامل (5 جلسات مكثفة)
   - تشخيص ومواءمة مبدئي
   - خريطة وعي شخصية مخصصة
   - مهام وممارسات بين الجلسات
   - متابعة نصية مستمرة
   - إمكانية التقسيط على دفعتين

3. حزمة السيادة VIP — 1,000 ريال:
   - 8 جلسات مكثفة
   - 30 يوماً متابعة مكثفة بعد الجلسة 8
   - جلسة طوارئ عند الحاجة
   - خريطة وعي متقدمة ومخصصة
   - أولوية في حجز المواعيد
   - مهام وممارسات معمّقة
   - متابعة نصية مستمرة
   - إمكانية التقسيط على دفعتين

ملاحظات إجرائية:
- إيقاع الجلسات: التباعد بين الجلسة والأخرى لا يقل عن أسبوع ولا يتجاوز شهراً لضمان استمرارية الوعي.
- سياسة الالتزام المالي: يتم تحويل الرسوم (أو الدفعة الأولى) قبل الموعد بـ 24 ساعة.
- نظام الدفع: في باقات العبور والسيادة، تتوفر إمكانية التقسيط على دفعتين.

قواعد الرد:
- الرد باللغة العربية فقط
- كن ودوداً ومحترفاً ومشجعاً
- استخدم أسلوباً يناسب النساء (لأن الجمهور المستهدف نسائي)
- أجب بإيجاز ووضوح
- إذا سُئلت عن أسعار، اذكرها بوضوح
- إذا سُئلت عن شيء خارج نطاق راسية، أرشد السائلة للحجز لمناقشة ذلك مع الكوتش
- لا تعطي نصائح كوتشينج — أنت مجرد مساعد معلوماتي`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, history } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'الرسالة مطلوبة' }, { status: 400 });
    }

    const conversationMessages = [
      { role: 'system' as const, content: SYSTEM_PROMPT },
      ...(history || []).map((msg: { role: string; content: string }) => ({
        role: (msg.role === 'assistant' ? 'assistant' : 'user') as 'user' | 'assistant',
        content: msg.content,
      })),
      { role: 'user' as const, content: message },
    ];

    const { createChatCompletion } = await import('z-ai-web-dev-sdk');

    const completion = await createChatCompletion({
      model: 'glm-4-flash',
      messages: conversationMessages,
      temperature: 0.7,
      maxTokens: 500,
    });

    const assistantMessage =
      completion.choices?.[0]?.message?.content ||
      'عذراً، لم أتمكن من معالجة طلبكِ. يرجى المحاولة مرة أخرى.';

    return NextResponse.json({ message: assistantMessage });
  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json({
      message:
        'شكراً لتواصلكِ مع راسية! المساعد الذكي في وضع الصيانة حالياً. يرجى التواصل مع الكوتش مباشرة لحجز جلستكِ أو الاستفسار.',
    });
  }
}