'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { siteConfig } from '@/lib/site-config';
import {
  getBlogPosts,
  saveBlogPosts,
  getProducts,
  saveProducts,
  type BlogPost,
  type Product,
} from '@/lib/data-store';
import {
  ArrowRight,
  Plus,
  Trash2,
  BookOpen,
  ShoppingBag,
  Save,
  ArrowLeft,
  Link as LinkIcon,
} from 'lucide-react';

/* ────────────────────── Toast ────────────────────── */
function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 2500);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white px-6 py-3 rounded-xl shadow-lg text-sm font-medium animate-in fade-in slide-in-from-top-4">
      {message}
    </div>
  );
}

/* ────────────────────── Blog Form ────────────────────── */
function BlogForm({
  post,
  index,
  onSave,
  onDelete,
}: {
  post: BlogPost;
  index: number;
  onSave: (i: number, p: BlogPost) => void;
  onDelete: (i: number) => void;
}) {
  const [form, setForm] = useState(post);

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
            <BookOpen className="w-4 h-4 text-sky-500" />
            مقال {index + 1}
          </div>
          <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600 hover:bg-red-50 cursor-pointer h-8 w-8 p-0" onClick={() => onDelete(index)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
        <Input
          placeholder="عنوان المقال"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="text-right"
        />
        <textarea
          placeholder="ملخص المقال..."
          value={form.excerpt}
          onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
          className="w-full min-h-[80px] rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-right resize-y focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            placeholder="التاريخ (مثال: 2025-07-01)"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className="text-right"
          />
          <div className="relative">
            <LinkIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="رابط المقال"
              value={form.link}
              onChange={(e) => setForm({ ...form, link: e.target.value })}
              className="text-right pr-9"
              dir="ltr"
            />
          </div>
        </div>
        <div className="relative">
          <LinkIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="رابط صورة (اختياري)"
            value={form.image || ''}
            onChange={(e) => setForm({ ...form, image: e.target.value })}
            className="text-right pr-9"
            dir="ltr"
          />
        </div>
        <Button size="sm" className="bg-sky-600 hover:bg-sky-700 text-white cursor-pointer" onClick={() => onSave(index, form)}>
          <Save className="w-4 h-4 ml-1" /> حفظ التعديلات
        </Button>
      </CardContent>
    </Card>
  );
}

/* ────────────────────── Product Form ────────────────────── */
function ProductForm({
  product,
  index,
  onSave,
  onDelete,
}: {
  product: Product;
  index: number;
  onSave: (i: number, p: Product) => void;
  onDelete: (i: number) => void;
}) {
  const [form, setForm] = useState(product);

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
            <ShoppingBag className="w-4 h-4 text-emerald-500" />
            منتج {index + 1}
          </div>
          <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600 hover:bg-red-50 cursor-pointer h-8 w-8 p-0" onClick={() => onDelete(index)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
        <Input
          placeholder="اسم الكتيب"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="text-right"
        />
        <textarea
          placeholder="وصف مختصر..."
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="w-full min-h-[80px] rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-right resize-y focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            placeholder="السعر (ريال)"
            type="number"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
            className="text-right"
          />
          <div className="relative">
            <LinkIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="رابط الصورة (اختياري)"
              value={form.image || ''}
              onChange={(e) => setForm({ ...form, image: e.target.value })}
              className="text-right pr-9"
              dir="ltr"
            />
          </div>
        </div>
        <Button size="sm" className="bg-sky-600 hover:bg-sky-700 text-white cursor-pointer" onClick={() => onSave(index, form)}>
          <Save className="w-4 h-4 ml-1" /> حفظ التعديلات
        </Button>
      </CardContent>
    </Card>
  );
}

/* ────────────────────── Admin Page ────────────────────── */
export default function AdminPage() {
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [toast, setToast] = useState('');

  useEffect(() => {
    setBlogPosts(getBlogPosts(siteConfig.blogPosts));
    setProducts(getProducts(siteConfig.products));
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    window.dispatchEvent(new Event('rasiya-data-updated'));
  };

  /* ── Blog Actions ── */
  const addBlogPost = () => {
    const newPost: BlogPost = { title: '', excerpt: '', date: new Date().toISOString().slice(0, 10), link: '#' };
    const updated = [...blogPosts, newPost];
    setBlogPosts(updated);
    saveBlogPosts(updated);
    showToast('تم إضافة مقال جديد');
  };

  const saveBlogPost = (index: number, post: BlogPost) => {
    const updated = [...blogPosts];
    updated[index] = post;
    setBlogPosts(updated);
    saveBlogPosts(updated);
    showToast('تم حفظ المقال');
  };

  const deleteBlogPost = (index: number) => {
    const updated = blogPosts.filter((_, i) => i !== index);
    setBlogPosts(updated);
    saveBlogPosts(updated);
    showToast('تم حذف المقال');
  };

  /* ── Product Actions ── */
  const addProduct = () => {
    const newProd: Product = { name: '', description: '', price: 0 };
    const updated = [...products, newProd];
    setProducts(updated);
    saveProducts(updated);
    showToast('تم إضافة منتج جديد');
  };

  const saveProduct = (index: number, product: Product) => {
    const updated = [...products];
    updated[index] = product;
    setProducts(updated);
    saveProducts(updated);
    showToast('تم حفظ المنتج');
  };

  const deleteProduct = (index: number) => {
    const updated = products.filter((_, i) => i !== index);
    setProducts(updated);
    saveProducts(updated);
    showToast('تم حذف المنتج');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {toast && <Toast message={toast} onClose={() => setToast('')} />}

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-gray-200">
        <div className="container mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="sm" className="cursor-pointer">
              <a href="/">
                <ArrowRight className="w-4 h-4 ml-1" /> الرئيسية
              </a>
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <h1 className="text-xl font-bold text-gray-900">لوحة التحكم</h1>
          </div>
          <span className="text-sm text-gray-400 hidden sm:block">راسية — إدارة المحتوى</span>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 py-10 space-y-12 max-w-4xl">

        {/* Blog Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-sky-500" />
                المدونة
              </h2>
              <p className="text-gray-500 text-sm mt-1">{blogPosts.length} مقال</p>
            </div>
            <Button onClick={addBlogPost} className="bg-sky-600 hover:bg-sky-700 text-white cursor-pointer">
              <Plus className="w-4 h-4 ml-1" /> إضافة مقال
            </Button>
          </div>
          <div className="space-y-4">
            {blogPosts.map((post, i) => (
              <BlogForm key={i} post={post} index={i} onSave={saveBlogPost} onDelete={deleteBlogPost} />
            ))}
            {blogPosts.length === 0 && (
              <p className="text-center text-gray-400 py-10">لا توجد مقالات بعد. اضغطي &quot;إضافة مقال&quot; للبدء.</p>
            )}
          </div>
        </section>

        <Separator />

        {/* Products Section */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <ShoppingBag className="w-6 h-6 text-emerald-500" />
                المنتجات
              </h2>
              <p className="text-gray-500 text-sm mt-1">{products.length} منتج</p>
            </div>
            <Button onClick={addProduct} className="bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer">
              <Plus className="w-4 h-4 ml-1" /> إضافة منتج
            </Button>
          </div>
          <div className="space-y-4">
            {products.map((prod, i) => (
              <ProductForm key={i} product={prod} index={i} onSave={saveProduct} onDelete={deleteProduct} />
            ))}
            {products.length === 0 && (
              <p className="text-center text-gray-400 py-10">لا توجد منتجات بعد. اضغطي &quot;إضافة منتج&quot; للبدء.</p>
            )}
          </div>
        </section>

        {/* Info */}
        <Card className="bg-sky-50 border-sky-100">
          <CardContent className="p-5 text-sm text-sky-800 leading-relaxed">
            <strong>ملاحظة:</strong> التغييرات تُحفظ في المتصفح تلقائياً. تظهر على الموقع فوراً بعد الحفظ.
            يمكن الوصول لهذه الصفحة من الرابط: <code className="bg-sky-100 px-1.5 py-0.5 rounded text-xs" dir="ltr">/admin</code>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}